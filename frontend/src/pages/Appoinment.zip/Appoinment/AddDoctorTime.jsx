import React, { useState } from 'react';
import axios from 'axios';

const AddDoctorTime = () => {
  const [doctorID, setDoctorID] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);

    try {
      const response = await axios.post('http://localhost:5000/doctortime/add', {
        doctorID,
        date,
        time,
      });
      console.log(response.data);
      alert('Availability added successfully');
      // Clear the form or redirect as needed
    } catch (error) {
      console.error('Error adding availability:', error);
      alert('Error adding availability');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-xs m-auto mt-10">
      <h2 className="text-2xl font-semibold mb-6 text-center">Manage Doctor Availability</h2>
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        {/* Doctor ID */}
        <div className="mb-4">
          <label htmlFor="doctorID" className="block text-gray-700 text-sm font-bold mb-2">Doctor ID:</label>
          <input
            id="doctorID"
            type="text"
            name="doctorID"
            value={doctorID}
            onChange={(e) => setDoctorID(e.target.value)}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            required
          />
        </div>

        {/* Date */}
        <div className="mb-4">
          <label htmlFor="date" className="block text-gray-700 text-sm font-bold mb-2">Date:</label>
          <input
            id="date"
            type="date"
            name="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            required
          />
        </div>

        {/* Time */}
        <div className="mb-4">
          <label htmlFor="time" className="block text-gray-700 text-sm font-bold mb-2">Time:</label>
          <input
            id="time"
            type="time"
            name="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            required
          />
        </div>

        {/* Submit Button */}
        <div className="flex items-center justify-between">
          <button
            type="submit"
            disabled={submitting}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          >
            Add Availability
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddDoctorTime;
