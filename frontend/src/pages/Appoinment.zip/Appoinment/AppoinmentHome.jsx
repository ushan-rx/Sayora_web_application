// import React, { useEffect, useState } from 'react';

// const AppoinmentHome = () => {
//     const [doctors, setDoctors] = useState([]);
//     const [speciality, setSpeciality] = useState('All');
//     const [search, setSearch] = useState('');
//     const [doctorTimeList , setDoctorTimeList] = useState([]);
//     const [selectedDoctor, setSelectedDoctor] = useState(null);

//     useEffect(() => {
//         const fetchDoctors = async () => {
//             try {
//                 const response = await axios.get('http://localhost:5000/api/v1/doctor');
//                 setDoctors(response.data);
//             } catch (error) {
//                 console.error('Error fetching doctors:', error);
//             }
//         }

//         const fetchDoctorTime = async () => {
//             try{
//                 const response = await axios.get('http://localhost:5000/api/v1/doctorTime');
//                 setDoctorTimeList(response.data);
//             }catch(error){
//                 console.error('Error fetching doctors:', error);
//             }
//         }

//         fetchDoctors();
//         fetchDoctorTime();
//         }
//     , [])

//         setSelectedDoctor(setSearch(doctors.filter(doctor => {
//             if (speciality === 'All') {
//                 return true;
//             }else{
//                 return doctor.speciality === speciality;
//             }
//             }).filter(doctor => doctor.name.toLowerCase().includes(search.toLowerCase()))));

//     return (
//         <div className='flex flex-col items-center mx-auto'>
//             <h1 className='text-3xl font-bold m-7'>Find a Doctor</h1>
//             <div className='flex flex-col'>
//                 <div className='flex flex-row'>
//                     <input type='text' placeholder='Search' className='border p-2 m-2'
//                         onChange={(event) => setSearch(event.target.value)}
//                     />
//                     <button className='bg-blue-500 text-white m-2 py-2 px-5'>Search</button>
//                 </div>
//                 <div className='flex flex-row'>
//                     <button className='bg-blue-500 text-white m-2 py-2 px-5' onClick={setSpeciality('All')}>All</button>
//                     <button className='bg-blue-500 text-white m-2 py-2 px-5' onClick={setSpeciality('Dentist')}>Dentist</button>
//                     <button className='bg-blue-500 text-white m-2 py-2 px-5' onClick={setSpeciality('Cardiologist')}>Cardiologist</button>
//                     <button className='bg-blue-500 text-white m-2 py-2 px-5' onClick={setSpeciality('Neurologist')}>Neurologist</button>
//                     <button className='bg-blue-500 text-white m-2 py-2 px-5' onClick={setSpeciality('Gynecologist')}>Gynecologist</button>
//                     <button className='bg-blue-500 text-white m-2 py-2 px-5' onClick={setSpeciality('Orthopedic')}>Orthopedic</button>
//                 </div>
//             </div>
//             <div className=''>

//             </div>
//         </div>
//     );
// };

// export default AppoinmentHome;

import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AppoinmentHome = () => {
  const [doctors, setDoctors] = useState([]);
  const [speciality, setSpeciality] = useState("All");
  const [search, setSearch] = useState("");
  const [doctorTimeList, setDoctorTimeList] = useState([]);
  const [filteredDoctors, setFilteredDoctors] = useState([]);
  const [results, setResults] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDoctorsAndTimes = async () => {
      try {
        const doctorsResponse = await axios.get(
          "http://localhost:5000/api/v1/doctor"
        );
        const timesResponse = await axios.get(
          "http://localhost:5000/doctorTime/getAll"
        );
        setDoctors(doctorsResponse.data.doctors);
        console.log(doctorsResponse.data.doctors);
        setDoctorTimeList(timesResponse.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchDoctorsAndTimes();
  }, []);

  useEffect(() => {
    // let results = doctors;
    setResults(doctors);
    // console.log(doctors);
    if (speciality !== "All") {
      if (results.length > 0) {
        setResults(
          results.filter((doctor) =>
            doctor.specialization.filter((spec) => {
              spec.name === speciality;
              console.log(spec.name);
            })
          )
        );
      }
    }

    if (search) {
      if (results.length > 0) {
        setResults(
          results.filter((doctor) =>
            `${doctor.fName} ${doctor.lName}`
              .toLowerCase()
              .includes(search.toLowerCase())
          )
        );
      }
    }

    setFilteredDoctors(results);
    // console.log(results)
  }, [doctors, speciality, search]);

  const handleSpecialityChange = (speciality) => {
    setSpeciality(speciality);
  };

  // Function to handle search
  const handleSearch = () => {
    // The search functionality is handled by the useEffect above
  };

  const handleNavigate = (doctor, App_date, App_time) => {
    const doctorID = doctor.doctorId;
    navigate(`/appoinment/addAppoinment`, {
      state: { doctorID, App_date, App_time },
    });
  };

  return (
    <div className="flex flex-col items-center mx-auto">
      <h1 className="text-3xl font-bold m-7">Find a Doctor</h1>
      <div className="flex flex-col">
        <div className="flex flex-row">
          <input
            type="text"
            placeholder="Search"
            className="border p-2 m-2"
            onChange={(event) => setSearch(event.target.value)}
          />
          <button
            onClick={handleSearch}
            className="bg-blue-500 text-white m-2 py-2 px-5"
          >
            Search
          </button>
        </div>
      </div>
      {/* ... */}
      <div className="flex flex-row">
        <button
          onClick={() => handleSpecialityChange("All")}
          className="bg-blue-500 text-white m-2 py-2 px-5"
        >
          All
        </button>
        <button
          onClick={() => handleSpecialityChange("Dentist")}
          className="bg-blue-500 text-white m-2 py-2 px-5"
        >
          Dentist
        </button>
        <button
          className="bg-blue-500 text-white m-2 py-2 px-5"
          onClick={() => handleSpecialityChange("Cardiologist")}
        >
          Cardiologist
        </button>
        <button
          className="bg-blue-500 text-white m-2 py-2 px-5"
          onClick={() => handleSpecialityChange("Neurologist")}
        >
          Neurologist
        </button>
        <button
          className="bg-blue-500 text-white m-2 py-2 px-5"
          onClick={() => handleSpecialityChange("Gynecologist")}
        >
          Gynecologist
        </button>
        <button
          className="bg-blue-500 text-white m-2 py-2 px-5"
          onClick={() => handleSpecialityChange("Orthopedic")}
        >
          Orthopedic
        </button>
      </div>
      <div className="">
        {results.length > 0 ? (
          results.map((doctor) => {
            const doctorTimes = doctorTimeList.filter(
              (time) => time.doctorID === doctor.doctorId
            );
            return (
              <div key={doctor.doctorId} className="flex flex-col items-center">
                <div className="m-5">
                  <h3 className="text-lg font-bold">
                    {doctor.fName} {doctor.lName} -{" "}
                    {doctor.specialization.map((spec) => spec.name).join(", ")}
                  </h3>
                  {doctorTimes.length > 0 ? (
                    doctorTimes.map((time) => (
                      <div
                        key={`${doctor.doctorId}-${time.date}-${time.time}`}
                        className="w-22 h-26 "
                      >
                        <span>
                          {new Date(time.date).toLocaleDateString()} -{" "}
                          {time.time}
                        </span>
                        <button
                          className="bg-blue-500 text-white m-2 py-2 px-5"
                          onClick={() =>
                            handleNavigate(doctor, time.date, time.time)
                          }
                        >
                          Book Appointment
                        </button>
                      </div>
                    ))
                  ) : (
                    <>
                      <div> No Allocated Time</div>
                    </>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div>No doctors found</div>
        )}
      </div>
      {/* ... */}
    </div>
  );
};

export default AppoinmentHome;
