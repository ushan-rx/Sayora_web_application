import React, { useEffect, useState } from "react";
import axios from "axios";

const ViewAppointment = () => {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const response = await axios.get("http://localhost:5000/appointments");
      setAppointments(response.data);
      console.log(response.data);
    } catch (error) {
      console.error("Error fetching appointments:", error);
    }
  };

  const updateStatus = async (appId, newStatus) => {
    try {
      const response = await axios.put(
        `http://localhost:5000/updateappointments/${appId}`,
        { status: newStatus }
      );
      console.log("Status updated:", response.data);
      alert("Appointment status updated successfully.");
      fetchAppointments(); // Refresh the list after update
    } catch (error) {
      console.error("Error updating appointment status:", error);
      alert("Failed to update appointment status.");
    }
  };

  const statusColor = (status) => {
    switch (status) {
      case "Pending":
        return "text-green-500";
      case "Approved":
        return "text-blue-500";
      case "Cancel":
        return "text-red-500";
      case "Completed":
        return "text-gray-500";
      default:
        return "text-black";
    }
  };

  const deleteAppointment = async (appId) => {
    if (window.confirm("Are you sure you want to delete this appointment?")) {
      try {
        await axios.delete(`http://localhost:5000/deleteappointments/${appId}`);
        fetchAppointments(); // Refresh the list after deletion
        alert("Appointment deleted successfully.");
      } catch (error) {
        console.error("Error deleting appointment:", error);
        alert("Failed to delete appointment.");
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h2 className="text-3xl font-semibold text-center mb-4">Appointments</h2>
      <table className="w-full text-sm text-left text-gray-500">
        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3">
              Patient Name
            </th>
            <th scope="col" className="px-6 py-3">
              Date
            </th>
            <th scope="col" className="px-6 py-3">
              Time
            </th>
            <th scope="col" className="px-6 py-3">
              Reason
            </th>
            <th scope="col" className="px-6 py-3">
              Status
            </th>
            <th scope="col" className="px-6 py-3">
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          {appointments.map((appointment) => (
            <tr key={appointment.App_Id} className="bg-white border-b">
              <td className="px-6 py-4">{appointment.patientName}</td>
              <td className="px-6 py-4">
                {new Date(appointment.App_date).toLocaleDateString()}
              </td>
              <td className="px-6 py-4">{appointment.App_time}</td>
              <td className="px-6 py-4">{appointment.App_reason}</td>
              <td className={`px-6 py-4 ${statusColor(appointment.status)}`}>
                {appointment.status}
              </td>
              <td className="px-6 py-4">
                <button
                  onClick={() => updateStatus(appointment.App_Id, "Pending")}
                  className="text-yellow-600 hover:text-yellow-700 underline font-medium py-1 px-3 focus:outline-none"
                >
                  Pending
                </button>
                <button
                  onClick={() => updateStatus(appointment.App_Id, "Approved")}
                  className="text-green-600 hover:text-green-700 underline font-medium py-1 px-3 focus:outline-none"
                >
                  Approved
                </button>
                <button
                  onClick={() => updateStatus(appointment.App_Id, "Canceled")}
                  className="text-red-600 hover:text-red-700 underline font-medium py-1 px-3 focus:outline-none"
                >
                  Canceled
                </button>
                <button
                  onClick={() => updateStatus(appointment.App_Id, "Completed")}
                  className="text-blue-600 hover:text-blue-700 underline font-medium py-1 px-3 focus:outline-none"
                >
                  Completed
                </button>

                <button
                  onClick={() => deleteAppointment(appointment.App_Id)}
                  className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded focus:outline-none focus:shadow-outline"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewAppointment;
