import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ViewDoctorTIme = () => {
  const [availability, setAvailability] = useState([]);
  const [doctors, setDoctors] = useState({});
  const navigate = useNavigate();
  useEffect(() => {
    const fetchAvailability = async () => {
      try {
        const { data } = await axios.get(
          "http://localhost:5000/doctortime/getAll"
        );
        setAvailability(data);

        const uniqueDoctorIds = [...new Set(data.map((slot) => slot.doctorID))];
        const doctorDetails = await Promise.all(
          uniqueDoctorIds.map((id) =>
            axios
              .get(`http://localhost:5000/api/v1/doctor/${id}`)
              .then((response) => ({ id, details: response.data }))
          )
        );

        setDoctors(
          doctorDetails.reduce(
            (acc, { id, details }) => ({ ...acc, [id]: details }),
            {}
          )
        );
        console.log(doctors);
      } catch (error) {
        console.error("Error fetching doctor availability:", error);
      }
    };

    fetchAvailability();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/doctortime/delete/${id}`);
      setAvailability(availability.filter((slot) => slot._id !== id));
      alert('Available Time Deleted..')
    } catch (error) {
      console.error("Error deleting availability time:", error);
    }
  };
     console.log(availability);
  const handleUpdate = (id) => {
    // Logic to navigate to the update page or open a modal for update
    navigate('/appoinment/time/update' , { state: id })
    // console.log("Navigate to update for id:", id);
  };

  return (
    <div className="mx-8">
      <h2 className="text-2xl text-center text-blue-700 font-bold mb-4 mt-4">
        Doctor Availability Times
      </h2>
      <div className="overflow-x-auto relative shadow-md sm:rounded-lg">
        <table className="w-full text-sm text-left text-blue-800">
          <thead className="text-xs text-white uppercase bg-blue-700">
            <tr>
              <th scope="col" className="py-3 px-6">
                Doctor Name
              </th>
              <th scope="col" className="py-3 px-6">
                Date
              </th>
              <th scope="col" className="py-3 px-6">
                Time
              </th>
              <th scope="col" className="py-3 px-6">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {availability.map((slot) => {
              const doctorDetails = doctors[slot.doctorID]?.doctor;
              return (
                <tr
                  key={slot._id}
                  className="bg-blue-100 border-b border-blue-200"
                >
                  <td className="py-4 px-6">
                    {doctorDetails
                      ? `${doctorDetails.fName} ${doctorDetails.lName}`
                      : "Loading..."}
                  </td>
                  <td className="py-4 px-6">
                    {new Date(slot.date).toLocaleDateString()}
                  </td>
                  <td className="py-4 px-6">{slot.time}</td>
                  <td className="py-4 px-6">
                    <button
                      onClick={() => handleUpdate(slot._id)}
                      className="text-blue-700 hover:text-blue-900 underline pl-6 pr-3 py-1 transition duration-300 ease-in-out"
                    >
                      Update
                    </button>
                    <button
                      onClick={() => handleDelete(slot._id)}
                      className="text-red-600 hover:text-red-800 underline pl-3 pr-6 py-1 transition duration-300 ease-in-out"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {availability.length === 0 && (
        <p className="text-center text-blue-800">
          No availability times to display.
        </p>
      )}
    </div>
  );
};

export default ViewDoctorTIme;
