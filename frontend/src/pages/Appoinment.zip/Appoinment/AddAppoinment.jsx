import React from 'react';
import { useFormik } from 'formik';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { useLocation } from 'react-router-dom';

const AddAppointment = () => {
  // Assuming `App_date`, `App_time`, and `doctorID` are passed as route parameters
  // const { App_date, App_time, doctorID } = useParams();
  const location = useLocation();
  const { App_date, App_time, doctorID } = location.state || {} ;
  console.log('doctorID:', doctorID);
  console.log('App_date:', App_date);
  console.log('App_time:', App_time);


  const formik = useFormik({
    initialValues: {
      App_date: App_date ,
      App_time: App_time,
      doctorID: doctorID,
      App_reason: '',
      patientName: '',
      patientAddress: '',
      patientContact: '',
      patientGender: '',
      patientemail: '',
    },
    onSubmit: async (values) => {
      try {
        // Replace this URL with the actual endpoint to which the appointment data should be posted
        const response = await axios.post('http://localhost:5000/addappointments', values);
        alert('Appointment created successfully!');
        console.log('Appointment created:', response.data);
      } catch (error) {
        alert('Error creating appointment.');
        console.error('Error creating appointment:', error);
      }
    },
  });

  return (
    <div className='w-full max-w-md m-auto mt-10'>
      <h2 className='text-2xl font-semibold mb-6 text-center'>Add Appointment</h2>
      <form onSubmit={formik.handleSubmit} className='bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4'>
        {/* App_reason */}
        <div className='mb-4'>
          <label htmlFor='App_reason' className='block text-gray-700 text-sm font-bold mb-2'>Reason for Appointment:</label>
          <input
            id='App_reason'
            type='text'
            name='App_reason'
            onChange={formik.handleChange}
            value={formik.values.App_reason}
            className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
            required
          />
        </div>

        {/* patientName */}
        <div className='mb-4'>
          <label htmlFor='patientName' className='block text-gray-700 text-sm font-bold mb-2'>Patient Name:</label>
          <input
            id='patientName'
            type='text'
            name='patientName'
            onChange={formik.handleChange}
            value={formik.values.patientName}
            className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
            required
          />
        </div>

        {/* patientAddress */}
        <div className='mb-4'>
          <label htmlFor='patientAddress' className='block text-gray-700 text-sm font-bold mb-2'>Patient Address:</label>
          <input
            id='patientAddress'
            type='text'
            name='patientAddress'
            onChange={formik.handleChange}
            value={formik.values.patientAddress}
            className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
            required
          />
        </div>

        {/* patientContact */}
        <div className='mb-4'>
          <label htmlFor='patientContact' className='block text-gray-700 text-sm font-bold mb-2'>Patient Contact:</label>
          <input
            id='patientContact'
            type='text'
            name='patientContact'
            onChange={formik.handleChange}
            value={formik.values.patientContact}
            className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
            required
          />
        </div>

        {/* patientGender */}
        <div className='mb-4'>
          <label htmlFor='patientGender' className='block text-gray-700 text-sm font-bold mb-2'>Patient Gender:</label>
          <select
            id='patientGender'
            name='patientGender'
            onChange={formik.handleChange}
            value={formik.values.patientGender}
            className='shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
            required
          >
            <option value='' disabled>Select Gender</option>
            <option value='Male'>Male</option>
            <option value='Female'>Female</option>
          </select>
        </div>

        {/* patientemail */}
        <div className='mb-4'>
          <label htmlFor='patientemail' className='block text-gray-700 text-sm font-bold mb-2'>Patient Email:</label>
          <input
            id='patientemail'
            type='email'
            name='patientemail'
            onChange={formik.handleChange}
            value={formik.values.patientemail}
            className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
            required
          />
        </div>

        {/* Submit button */}
        <div className='flex items-center justify-between'>
          <button
            type='submit'
            className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline'
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddAppointment;
